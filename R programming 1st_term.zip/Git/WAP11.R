squares=function(a)
{
  i=1
  while(i<=a){
    b=i*i
    cat(b," ")
    i=i+1
  }
}

squares(10)