myfunc=function(a)
{
  i=1
  while(i<=a)
  {
    cat("Hello"," ")
    i=i+1
  }
}