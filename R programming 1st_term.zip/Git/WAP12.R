funvector=function(a)
{
  b=a+1
}
#i/p
#print(funvector(c(1:10)))