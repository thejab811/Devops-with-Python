mysum=function(a,b)
{
  s=a+b
  return(s)
}
#i/p
#mysum(2,4)