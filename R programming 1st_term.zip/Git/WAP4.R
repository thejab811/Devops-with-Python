j=1
while(j<=5)
{
i=5
while(i>=1)
{
  cat(i," ")
  i=i-1
}
cat("\n")
j=j+1
}
