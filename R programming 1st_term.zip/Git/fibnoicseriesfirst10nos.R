a=0
b=1
c
d=0
repeat{
  if(d>=10){break}
  cat(a," ")
  c=a+b
  a=b
  b=c
  d=d+1
}