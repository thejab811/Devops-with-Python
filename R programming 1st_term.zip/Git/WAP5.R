j=0
i=9
 while(j<=3)
{
k=0
while(i>=1)
{
  cat(i," ")
  i=i-1
  k=k+1
  if(k%%3==0){cat("\n")}
}
j=j+1
}