neo<-function(a,b,...)
{
  invisible(seq(a,b,...))
}
#i/p
#print(neo(1,10,3))