myfunc1=function(a=6,b=4)
{
  s=a+b
  print(s)
}
#i/p
#myfunc1()