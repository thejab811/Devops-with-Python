greeting=function()
{
  print("Hello.. Good Morning")
}