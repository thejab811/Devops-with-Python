i=0
repeat{
  cat(i," ")
  if(i==10){break}
  i=i+1
}