i=0
while(i<10)
{
  cat(i," ")
  i=i+1
}