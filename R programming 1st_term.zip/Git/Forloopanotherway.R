a=1:10
for(i in a)
{
  if(i%%2==0)
  {
    cat(i," ")
  }
}