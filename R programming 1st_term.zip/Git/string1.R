a="Hi"
b="Good Morning"
c=paste(a,b,sep=" ")
print(c)