a=1:10
b=20:30
print("a=",a)
cat("a=",a)
cat("\n")
cat("a=",a,"\n","b=",b)
