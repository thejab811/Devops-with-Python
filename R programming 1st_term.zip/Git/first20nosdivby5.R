i=1
j=0
repeat
{
  if(j==20){break}
  if(i%%5==0)
  {
    cat(i," ")
    j=j+1
  }
  i=i+1
}