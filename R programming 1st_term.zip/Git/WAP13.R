stringfun=function(a,b)
{
  c=paste(a,b,sep=" ")
  print(c)
}
#i/p
#stringfun("saikiran","GST")