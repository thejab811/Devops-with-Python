i=0
repeat{
  cat(i," ")
  i=i+1
}