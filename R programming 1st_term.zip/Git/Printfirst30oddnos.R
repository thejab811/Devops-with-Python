a=1:60
for(i in a)
{
  if(i%%2==1)
  {
    cat(i," ")
  }
}