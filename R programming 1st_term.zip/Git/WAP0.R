i=1
j=0
repeat{
  if(j==30){break}
  if(i%%2==1)
  {
    cat(i," ")
    j=j+1
  }
  i=i+1
}