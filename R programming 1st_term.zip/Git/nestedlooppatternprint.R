j=1
while(j<4)
{
  i=1
  while(i<6)
  {
    cat(i," ")
    i=i+1
  }
  cat("\n")
  j=j+1
}