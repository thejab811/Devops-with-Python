a=c("Hi","Good Morning")
c=paste(a,collapse ="_")
print(c)