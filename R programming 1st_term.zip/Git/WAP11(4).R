mysum1=function(a,b)
{
  s=a+b
}
#i/p
#print(mysum1(2,4))