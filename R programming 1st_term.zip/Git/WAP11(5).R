mysum2=function(a,b)
{
  s=a+b
  b=100# since b is the last object in this block, bwill be returned.
}
#i/p
#print(mysum2(2,4))
